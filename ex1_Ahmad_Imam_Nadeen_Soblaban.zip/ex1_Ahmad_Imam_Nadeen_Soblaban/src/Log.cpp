#include"Log.h"

Log::Log(const shared_ptr<Function> f1, double base)
	: fun1(f1), m_base(base)
{
}

Log::~Log()
{
}

void Log::print()
{
	cout << "log"<<m_base ;
	cout << "(";
	fun1->print();
	cout << ")"<<endl ;
}

double Log::calculateOutput(double x)
{

	double result1 = log(fun1->calculateOutput(x));
	double result2 = log(m_base);

	double result = result1 / result2;
	return result;
}

void Log::printresult(double x)
{
	cout << "log" << "(" << x << ")";
}






