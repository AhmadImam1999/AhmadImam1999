#include"Controller.h"

Controller::Controller() {}

Controller::~Controller() {}

// Run the Program 
void Controller::run()
{
	m_func.resize(2);

	// Program Gates
	m_func[0] = make_shared<Sin>();
	m_func[1] = make_shared<Ln>();

	printCommandsList();
	string str;

	cin >> str; // get User Input

	while (true) {


		Command_t cmd = commandIndex(str);
		if (doCommand(cmd))
			printCommandsList();

		cin >> str;

	}
}

// Print the commands List for the user
void Controller::printCommandsList()
{
	cout << endl << endl << "This is the function list:" << endl;

	for (size_t i = 0; i < m_func.size(); i++)
	{
		cout << i << ".        ";
		m_func[i]->print();
		cout << endl;

	}
	cout << "Please enter a command ('help' for command list):" << endl;
}

// Pick the command that User Want
Command_t Controller::commandIndex(string str)
{
	if (str == "eval")
		return Eval_t;
	else if (str == "del")
		return Del_t;
	else if (str == "help")
		return Help_t;
	else if (str == "exit")
		return Exit_t;
	else if (str == "mul")
		return Mul_t;
	else if (str == "add")
		return Add_t;
	else if (str == "poly")
		return Poly_t;
	else if (str == "log")
		return Log_t;
	else if (str == "comp")
		return Comp_t;

}

// after picking Command, do the command
bool Controller::doCommand(Command_t cmd)
{
	switch (cmd)
	{
	case Eval_t:
		do_eval();
		return true;
	case Mul_t:
		do_mul();
		return true;

	case Help_t:		
		do_help();
		return true;

	case Exit_t:
		do_exit();
		return true;

	case Del_t:
		do_delete();
		return true;
		
	case Add_t:
		do_add();
		return true;

	case Poly_t:
		do_poly();
		return true;
	case Log_t:
		do_Log();
		return true;
	case Comp_t:
		do_Comp();
		return true;
	}
	return false;
}

// show the commands list for the user
void Controller::do_help()
{
	cout << "Following is the list of the calculator's available commands:" << endl;
	cout << "eval <uate> num x - Evaluates function #num on x" << endl;
	cout << "poly(nomial) N c0 c1 ... cN-1 -creates a polynomial with N coefficients " << endl;
	cout << "mul(tiply) num1 num2 - Creates a function that is the multiplication of\n"
		<< "function #num1 and function #num2" << endl;
	cout << "add num1 num2 - Creates a function that is the sum of function #num1 and\n"
		<< "function #num2" << endl;
	cout << "comp(osite) num1 num2 - Creates a function that is the composition of\n"
		<< "function #num1 and function #num2";
	cout << "log N num - Creates a function that computes log N of function #num" << endl;
	cout << "del(ete) num - Deletes function #num from function list" << endl;
	cout << "help - Prints this help screen" << endl;
	cout << "exit - Exits the program" << endl;
}


void Controller::do_eval()
{
	int funValue;
	cin >> funValue;
	double  num;
	cin >> num;
	m_func[funValue]->eval(num);

}

void Controller::do_exit()
{
	cout << "Goodbye";
	exit(EXIT_SUCCESS);
}

void Controller::do_delete()
{
	int funValue = 0;

	cin >> funValue;
	
	if (funValue <= m_func.size() - 1)
		m_func.erase(m_func.begin() + funValue);
	
	else
		cout << "Wrong Input" << endl; 
}
void Controller::do_mul()
{
	int f1, f2;
	cin >> f1 >> f2;
	if (f1 < m_func.size() && f2 < m_func.size())
	{
		m_func.push_back(std::make_shared<Mul>(m_func[f1], m_func[f2]));

	}
	else
		cout << "Wrong Input" << endl;

	
}

void Controller::do_add()
{
	int f1, f2;
	cin >> f1 >> f2;
	if (f1 < m_func.size() && f2 < m_func.size())
	{
		m_func.push_back(std::make_shared<Add>(m_func[f1], m_func[f2]));

	}
	else
		cout << "Wrong Input" << endl;
}

void Controller::do_Comp()
{
	int f1, f2;
	cin >> f1 >> f2;
	if (f1 < m_func.size() && f2 < m_func.size())
	{
		m_func.push_back(std::make_shared<Comp>(m_func[f1], m_func[f2]));

	}
}
void Controller::do_Log()
{														
	int f1;
	double base;
	cin >> base >>f1;
	if (f1 < m_func.size())
	{
		m_func.push_back(std::make_shared<Log>(m_func[f1],base));

	}
	else
		cout << "Wrong Input" << endl;
}

void Controller::do_poly()
{
	int deg;
	cin >> deg;
	vector <double> inp;
	inp.resize(deg);
	
	for (int i = 0; i < deg; i++) {
		cin >> inp[i];
	}
	m_pol=(std::make_shared<Poly>(deg, inp));
	m_func.push_back(m_pol);
	}


	  



