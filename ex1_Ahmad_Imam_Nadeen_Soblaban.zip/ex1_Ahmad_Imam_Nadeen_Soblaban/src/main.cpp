#include <iostream>
#include "Controller.h" 

int main() {

	// Start the Program
	Controller c;
	c.run();


	return 0;
}
