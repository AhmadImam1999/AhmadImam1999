#include"Mul.h"

Mul::Mul(const shared_ptr<Function> f1, const shared_ptr<Function> f2 )
	:fun1(f1), fun2(f2)
{
}

Mul::~Mul()
{
}

void Mul::print()
{
	cout << "(";
	fun1->print();
	cout << ")" << "*"<< "(";
	fun2->print();
	cout << ")"<<endl;

}

double Mul::calculateOutput(double x)
{

	double result1 = fun1->calculateOutput(x);
	double result2 = fun2->calculateOutput(x);
	
	double result = result1 * result2;
	return result;
}

void Mul::printresult(double x)
{
	cout << "mul" << "(";  fun1->printresult(x);
	cout << ")" << "*" << "("; fun2->printresult(x);
	cout << ")";
}








