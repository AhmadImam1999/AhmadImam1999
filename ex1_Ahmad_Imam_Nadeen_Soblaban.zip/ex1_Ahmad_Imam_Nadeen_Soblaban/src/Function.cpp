#include"Function.h"

Function::Function() {}

Function::~Function() {}

void Function::eval(double x)
{
	printresult(x); cout << "="<< calculateOutput(x) << endl;
}



