#include "..\include\Comp.h"

Comp::Comp(const shared_ptr<Function> f1, const shared_ptr<Function> f2)
	:fun1(f1), fun2(f2)
{
}

Comp::~Comp()
{
}

void Comp::print()
{

	cout << ""; 
	fun1->print();
	cout << "("; fun2->print();
	cout << ")";
	
	
}

double Comp::calculateOutput(double x)
{
	
	double result2 = fun2->calculateOutput(x);

	double result = fun1->calculateOutput(result2);
	return result;
}

void Comp::printresult(double x)
{
	cout << "comp" << "(" << x << ")";
}


