#include"Ln.h"




void Ln::print()
{
	cout << "Ln(x)";
}


double Ln::calculateOutput(double x)
{
	double result = log(x);
	return result;
}

void Ln::printresult(double x)
{
	cout << "ln" << "(" <<std::fixed << std::setprecision(2) << x << ")";
}

