#include "..\include\Poly.h"



Poly::Poly(int degree, vector<double>pol)
	:deg(degree)
{
	poly.resize(deg);
	
	for (int i = 0;i<deg ; i++) {
		poly[i] = pol[i];
	}

}

Poly::~Poly()
{
	poly.clear();
}

void Poly::print()
{
	
	for (int i = deg -1; i >= 0; i--) {
		if (poly[i] != 0) {
			cout << poly[i] << "x^" << i ;
			if (i != 0)
			{
				cout << "+";
			}
	 }

	}
}

double Poly::calculateOutput(double x)
{
	double result = 0;
	for (int i = deg - 1; i >= 0; i--) {
		if (poly[i] != 0) {
			
			
				result += poly[i] *pow(x,i);
			
		}

	}

	return result;
}

void Poly::printresult(double x)
{
	cout << "poly" << "(" << x << ")";
}

