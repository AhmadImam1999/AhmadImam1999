#include"Sin.h"
#include <iomanip>

void Sin::print()
{
	cout << "sin(x)";
}


double Sin::calculateOutput(double x)
{
	double result = sin(x);
	
	return result ;
}

void Sin::printresult(double x)
{
	cout << "sin" << "(" <<std ::fixed << std:: setprecision(2)<< x << ")";
}
