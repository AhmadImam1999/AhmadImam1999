#include"MainFunction.h"

MainFunction::MainFunction()
{
}

MainFunction::~MainFunction()
{
}
