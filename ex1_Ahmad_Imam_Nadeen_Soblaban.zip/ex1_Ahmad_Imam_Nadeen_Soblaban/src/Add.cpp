#include "..\include\Add.h"

Add::Add(const shared_ptr<Function> f1, const shared_ptr<Function> f2)
	:fun1(f1), fun2(f2)
{
}

Add::~Add()
{
}

void Add::print()
{
	cout << "(";
	fun1->print();
	cout << ")" << "+" << "(";
	fun2->print();
	cout << ")" << endl;
}

double Add::calculateOutput(double x)
{
	double result1 = fun1->calculateOutput(x);
	double result2 = fun2->calculateOutput(x);

	double result = result1 + result2;
	return result;
}

void Add::printresult(double x)
{
	cout << "add" << "(";  fun1->printresult(x);
	cout << ")" << "+" << "("; fun2->printresult(x);
	cout << ")" ;
}


