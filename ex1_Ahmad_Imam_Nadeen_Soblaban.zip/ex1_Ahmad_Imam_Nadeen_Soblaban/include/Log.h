#pragma once
#include"Function.h"


class Log : public Function
{
public:



	Log(const shared_ptr<Function> f1, double  base);
	virtual ~Log();
	virtual void print();
	virtual double calculateOutput(double x);
	virtual void printresult(double x);

private:

	shared_ptr<Function> fun1;
	double m_base;
};