#pragma once
#include"Function.h"
#include<cmath>
#include <iostream>
#include <iomanip>
#include <limits>


class MainFunction : public Function
{
public:

	MainFunction();
	~MainFunction();

protected:

};