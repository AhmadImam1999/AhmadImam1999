#pragma once
#include"Function.h"


class Poly : public Function
{
public:


	Poly(int deg, vector<double>pol);
	 ~Poly();
	virtual void print();
	virtual double calculateOutput(double x);
	virtual void printresult(double x);
	

private:
	int deg;
	vector<double> poly;
};