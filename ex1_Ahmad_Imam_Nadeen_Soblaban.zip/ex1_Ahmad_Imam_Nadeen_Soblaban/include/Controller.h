#pragma once
#include<iostream>
#include <vector>
#include <Function.h>
#include <Ln.h>
#include <Sin.h>
#include <MainFunction.h>
#include <Mul.h>
#include <Add.h>
#include <Poly.h>
#include <Log.h>
#include <Comp.h>
using namespace std;
using std::vector;
using std::make_shared;


// enums for the commands 
enum Command_t {
	Eval_t, Comp_t, Del_t, Exit_t, Help_t,Mul_t , Add_t , Poly_t,Log_t

};

class Controller
{
public:
	// Controller C-tor
	Controller();

	// Controller d-tor
	~Controller();

	/* Run the Program (Insert gates Vector with all the gates, and
	Get the user Input)
	*/
	void run();

	// Print all the Commands to get user Input
	void printCommandsList();
	Command_t commandIndex(string str);
	bool doCommand(Command_t cmd);





private:

	vector<shared_ptr<Function>> m_func;
	std::shared_ptr <Poly> m_pol;
	

	void do_help();
	void do_eval();
	void do_exit();
	void do_delete();
	void do_mul();
	void do_add();
	void do_poly();
	void do_Log();
	void do_Comp();
};
