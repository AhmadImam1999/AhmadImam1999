#pragma once
#include <iostream>
#include <vector>
#include <string> 
#include<cmath>
#include <iostream>
#include <iomanip>
#include <limits>

using namespace std;
using std::string;
using std::vector;

class Function
{
public:
	
	Function();

	
	~Function();

	virtual void print() = 0;

	virtual void eval(double x);
	virtual double calculateOutput(double x) = 0;
	virtual void printresult(double x) = 0;
protected:

	int m_inputSize;
};
