#pragma once
#include"MainFunction.h"

class Sin: public MainFunction
{
public:

	using MainFunction::MainFunction;
	virtual void print();
	virtual double calculateOutput(double x);
	virtual void printresult(double x);

};