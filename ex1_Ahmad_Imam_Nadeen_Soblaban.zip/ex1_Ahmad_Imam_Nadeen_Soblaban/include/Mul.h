#pragma once
#include"Function.h"


class Mul : public Function
{
public:


	
	Mul(const shared_ptr<Function> f1, const shared_ptr<Function> f2);
	virtual ~Mul();
	virtual void print();
	virtual double calculateOutput(double x);
	virtual void printresult(double x);


private:
	
	shared_ptr<Function> fun1;
	shared_ptr<Function> fun2;
};