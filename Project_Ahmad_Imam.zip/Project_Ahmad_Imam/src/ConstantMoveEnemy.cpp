#include "ConstantMoveEnemy.h"

ConstantMoveEnemy::ConstantMoveEnemy()
{
}

ConstantMoveEnemy::ConstantMoveEnemy(const sf::Texture& texture, const sf::Vector2f& pos, float size)
	:Enemy(texture, pos, size)
{

	m_inishialPosition = pos;
	m_shape.setTexture(&texture);
	m_shape.setSize(sf::Vector2f(size, size));
	m_shape.setPosition(m_inishialPosition);

}

ConstantMoveEnemy::~ConstantMoveEnemy()
{

}

Vector2f ConstantMoveEnemy::set_consDirection(sf::Vector2f& direction, float time)
{
	setConstant_Direction(time);
	return m_direction;
}

Vector2f ConstantMoveEnemy::setDirection(sf::Vector2f& direction, float time,int D)
{

	return set_consDirection(direction, time);
}








