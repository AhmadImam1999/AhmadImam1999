#include <iostream>
#include "Menu.h"


Menu::Menu()
{

	m_selectedItemIndex = 0;
	buildmenu();
	creatwindow();
	m_menuwindow.setSize(sf::Vector2u(width, height));
	m_background.setTexture(&Resources::instance().getMenu());
}



Menu::Menu(float width, float height)
	:m_width(width), m_hegiht(height)
{

	Resources::instance().loadresources();
	m_selectedItemIndex = 0;
	creatwindow();
	buildmenu();

	m_background.setTexture(&Resources::instance().getMenu());
	m_background.setSize(sf::Vector2f(width, height));
	
	m_music.openFromFile("menumusic.ogg");
	m_music.setLoop(true);
	m_music.play();

}

Menu::~Menu()
{
}

void Menu::drawButoons()
{
	for (size_t i = 0; i < NUM_OF_BUTTONS; i++)
	{
		m_menuwindow.draw(m_menu[i]);
	}
}

void Menu::creatwindow()
{
	m_menuwindow.create(sf::VideoMode(width, height), "MENU");
}

void Menu::draw()
{

	m_menuwindow.clear();

	m_menuwindow.draw(m_background);

	drawButoons();

	m_menuwindow.display();
}

void Menu::setsize(float width, float hefight)
{
	m_width = width;
	m_hegiht = hefight;
}

void Menu::buildmenu()
{
	m_menu[0].setFont(Resources::instance().getfont());
	m_menu[0].setFillColor(sf::Color::Red);
	m_menu[0].setString("Play");
	m_menu[0].setPosition(sf::Vector2f(width / 2 - 30, 240 + 73));
	m_menu[0].setScale(sf::Vector2f(1, 1));

	m_menu[1].setFont(Resources::instance().getfont());
	m_menu[1].setFillColor(sf::Color::White);
	m_menu[1].setString("Mute");
	m_menu[1].setPosition(sf::Vector2f(width / 2 - 33, 430));
	m_menu[1].setScale(sf::Vector2f(1, 1));


	m_menu[2].setFont(Resources::instance().getfont());
	m_menu[2].setFillColor(sf::Color::White);
	m_menu[2].setString("Exit");
	m_menu[2].setPosition(sf::Vector2f(width / 2 - 30, 550));
	m_menu[2].setScale(sf::Vector2f(1, 1));

}

void Menu::Handelmenu()
{
	sf::Event menuevent;

	while (m_menuwindow.pollEvent(menuevent))
	{


		switch (menuevent.type)
		{
		case sf::Event::Closed:
			m_menuwindow.close();
			break;

		case sf::Event::KeyPressed:
			switch (menuevent.key.code)
			{
			case sf::Keyboard::Up:
				moveup();
				break;
			case sf::Keyboard::Down:
				movedown();
				break;


			case sf::Keyboard::Return:
				switch (getselecteditem())
				{
				case 0:
				{
					m_music.stop();
					Controller control;
					control.run();
					break;
				}
				case 1:
					m_music.stop();
					
					m_help.setSize(sf::Vector2f(width, height));

					break;
				case 2:
					openAsk(m_menuwindow);
					break;
				}
			}

		}

	}

}




void Menu::moveup()
{
	if (m_selectedItemIndex - 1 >= 0)
	{
		m_menu[m_selectedItemIndex].setColor(sf::Color::White);
		m_selectedItemIndex--;
		m_menu[m_selectedItemIndex].setColor(sf::Color::Red);
	}
}

void Menu::movedown()
{
	if (m_selectedItemIndex + 1 < NUM_OF_BUTTONS)
	{
		m_menu[m_selectedItemIndex].setColor(sf::Color::White);
		m_selectedItemIndex++;
		m_menu[m_selectedItemIndex].setColor(sf::Color::Red);

	}
}

void Menu::run()
{
	while (m_menuwindow.isOpen())
	{

		Handelmenu();
		draw();
	}



}

void Menu::openAsk(sf::RenderWindow& window)//asking if you want to exit or to continue
{
	sf::RenderWindow ask(sf::VideoMode(600, 150), "Are you sure you want to exit", sf::Style::Close);
	sf::Event event;
	sf::Font font;
	font.loadFromFile("font.ttf");
	sf::Text exi("Exit", font, 40);
	exi.setPosition(75, 60.f);
	sf::Text con("Continue", font, 40);
	con.setPosition(250, 60.f);
	exi.setFillColor(sf::Color::Red);
	con.setFillColor(sf::Color::White);

	while (ask.isOpen())
	{
		while (ask.pollEvent(event))
		{
			switch (event.type)
			{
			case sf::Event::KeyPressed:
				if (event.key.code == (sf::Keyboard::Left))
				{
					exi.setFillColor(sf::Color::Red);
					con.setFillColor(sf::Color::White);
				}
				if (event.key.code == (sf::Keyboard::Right))
				{
					con.setFillColor(sf::Color::Red);
					exi.setFillColor(sf::Color::White);
				}
				if (event.key.code == (sf::Keyboard::Return))
				{
					if (exi.getFillColor() == sf::Color::Red)
					{
						ask.close();
						window.close();
					}
					if (con.getFillColor() == sf::Color::Red)
					{
						ask.close();
					}
				}
			}
		}

		ask.draw(exi);
		ask.draw(con);
		ask.display();
		ask.clear();
	}

}