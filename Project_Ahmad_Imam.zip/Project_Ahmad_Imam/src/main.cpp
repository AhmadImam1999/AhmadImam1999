﻿#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include "Controller.h"
#include "Setting.h"
#include "Enemy.h"
#include "Resources.h"
#include"Player.h"


int main()
{
	srand(time(NULL));							 //for randomise directions
	Menu menu(width, height);
	menu.run();

	return 0;

};
