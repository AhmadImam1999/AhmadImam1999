#include "NonSelfMovment.h"

NonSelfMovment::~NonSelfMovment()
{

}
