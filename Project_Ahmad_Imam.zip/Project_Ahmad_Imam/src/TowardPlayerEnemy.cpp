#include <iostream>
#include "TowardPlayerEnemy.h"
#include <cmath>
#include<cstdlib>



TowardPlayerEnemy::TowardPlayerEnemy(const sf::Texture& texture, const sf::Vector2f& pos, float size, Player player)
	:Enemy(texture, pos, size), m_player(player)
{
	m_inishialPosition = pos;
	m_shape.setTexture(&texture);
	m_shape.setSize(sf::Vector2f(size, size));
	m_shape.setPosition(m_inishialPosition);



}

TowardPlayerEnemy::~TowardPlayerEnemy()
{

}


Vector2f TowardPlayerEnemy::setDirection(sf::Vector2f& direction, float time,int D)
{
	float X = abs(m_player.getposition().x - m_shape.getPosition().x);
	float Y = abs(m_player.getposition().y - m_shape.getPosition().y);

	float dis = nearPlayer(X, Y);

	if (dis < 200.f)
	{
		{
			if (X>= 0)
				m_direction.x = m_Enemymovespeed * time;
			else
				m_direction.x = -m_Enemymovespeed * time;
			if (Y>= 0)
				m_direction.y = m_Enemymovespeed * time;
			else
				m_direction.y = -m_Enemymovespeed * time;
		}
	}
	else
		setRandomDirection(time);


	return m_direction;
}


float TowardPlayerEnemy::nearPlayer(float x, float y)
{
	return sqrt((x * x) + (y * y));
}
