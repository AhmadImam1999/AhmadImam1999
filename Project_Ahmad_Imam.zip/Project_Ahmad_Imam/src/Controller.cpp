#include "Controller.h"
#include "RandomMoveEnemy.h"
#include "TowardPlayerEnemy.h"
#include"ConstantMoveEnemy.h"
#include <iostream>
#include "Enemy.h"



Controller::Controller ()
	:m_enemyidx(0), m_level(1), m_MoneyAmount(0), m_levelTime(0), m_row(0), m_col(0), m_currentLife(3), m_currentMoney(0), m_currentScore(0)
{
	m_shape2.setSize(sf::Vector2f(45, 45));
	m_shape2.setScale(1, 1);
	openfile();
	m_scoreToolbar.setStyle(sf::Text::Bold);
	m_scoreToolbar.setCharacterSize(30);
	m_scoreToolbar.setPosition(10, 0);
	m_scoreToolbar.setFont(Resources::instance().getfont());
	m_scoreToolbar.setFillColor(sf::Color::White);
	m_scoreToolbar.setString(m_scoreString.str());
	m_music.openFromFile("GAME_MUSIC.ogg");
	m_music.setLoop(true);
	m_music.play();
	m_music.setVolume(10);
}

Controller::~Controller()
{
	m_file.close();
}



bool Controller::openfile()
{
	m_file.open(FILE_NAME);

	if (!m_file.is_open())
		return false;

	return true;
}



void Controller::loadlevel()
{

	m_currentMoney = m_MoneyAmount;

	clearObjects();
	char c;

	for (int i = 0; i < m_row; i++)
	{
		for (int j = 0; j < m_col; j++)
		{
			c = SHAPE_CHAR(m_matrix[i][j]);

			switch (c)
			{
			case PLAYER:
				m_player = std::make_unique<Player>(Resources::instance().getPlayer(), sf::Vector2f(j * (TILE_SIZE), i *( TILE_SIZE)), TILE_SIZE, m_currentLife, m_currentScore, m_MoneyAmount);
				break;

			case ENEMY:
			{

				if (m_level == 1) {
					m_Enemy.push_back(std::make_unique<RandomMoveEnemy>(Resources::instance().getEnemy1(), sf::Vector2f(j * TILE_SIZE, i * TILE_SIZE), TILE_SIZE));
					m_enemyidx++;
					break;
				}
				if (m_level == 2) {
					m_Enemy.push_back(std::make_unique<ConstantMoveEnemy>(Resources::instance().getEnemy2(), sf::Vector2f(j * TILE_SIZE, i * TILE_SIZE), TILE_SIZE));
					m_enemyidx++;
					break;
				}
				if (m_level == 3||m_level==4)
				{
					m_Enemy.push_back(std::make_unique<TowardPlayerEnemy>(Resources::instance().getEnemy3(), sf::Vector2f(j * TILE_SIZE, i * TILE_SIZE), TILE_SIZE, *m_player));
					m_enemyidx++;
					break;
				}
			
				break;
				
			}
		
			case WALL:
			{

				m_boardPtr.push_back(std::make_unique <Wall>(Resources::instance().getWall(), sf::Vector2f(j * TILE_SIZE, i * TILE_SIZE), TILE_SIZE));
				
				break;
			}

			case MONEY:
			{
				m_boardPtr.push_back(std::make_unique <Money>(Resources::instance().getMoney(), sf::Vector2f(j * TILE_SIZE, i * TILE_SIZE), TILE_SIZE));
				break;
			}
			case ROD:
			{
				m_boardPtr.push_back(std::make_unique <Rod>(Resources::instance().getRod(), sf::Vector2f(j * TILE_SIZE, i * TILE_SIZE), TILE_SIZE));
				break;
			}
			case LADDER:
			{	
				m_boardPtr.push_back(std::make_unique <Ladder>(Resources::instance().getLadder(), sf::Vector2f(j * TILE_SIZE, i * TILE_SIZE), TILE_SIZE));
				break;
			}
			case GIFT:
			{ 
				if (i % 4 == 0)
				{
					m_boardPtr.push_back(std::make_unique <AddScoreGift>(Resources::instance().getGift(), sf::Vector2f(j * TILE_SIZE, i * TILE_SIZE), TILE_SIZE));
				}
				if (i % 4 == 1)
				{
					m_boardPtr.push_back(std::make_unique<AddLifeGift>(Resources::instance().getGift2(), sf::Vector2f(j * TILE_SIZE, i * TILE_SIZE), TILE_SIZE));
				}
				if (i % 4 == 2)
				{
					m_boardPtr.push_back(std::make_unique<AddTimeGift>(Resources::instance().getGift3(), sf::Vector2f(j * TILE_SIZE, i * TILE_SIZE), TILE_SIZE));
				}
				if (i % 4 == 3)
				{
					m_boardPtr.push_back(std::make_unique<AddEnemyGift>(Resources::instance().getGift4(), sf::Vector2f(j * TILE_SIZE, i * TILE_SIZE), TILE_SIZE));

				}


				break;
			}
			case ' ':
				break;
			}

		}
	}
}

void Controller::draw()
{
	settoolbar();
	clearwindow();
	drawshapes();
	drawtoolboar();
	displaywindow();
}

void Controller::settoolbar()
{
	m_scoreString.str("");
	m_scoreString << "Life   " << m_player->getLife() << "   Score   " << m_player->getScore() << "   level   " <<m_level << "   Level Time   " << m_levelTime - (int)m_timer.getElapsedTime().asSeconds();
	m_scoreToolbar.setString(m_scoreString.str());
}

void Controller::drawEnemy()
{
	for (size_t i = 0; i < m_Enemy.size(); i++)
	{
		m_Enemy[i]->draw(m_window);
	}
}

void Controller::cratewindow()
{
	//set window
	m_window.create(sf::VideoMode(width, height), " LODE RUNNER", sf::Style::Default);

	//set window background
	m_background.setTexture(&Resources::instance().getBackround());
	m_background.setSize(sf::Vector2f(width, height));
}

void Controller::resertlevel()
{
	m_soundefect.setBuffer(Resources::instance().getRESETLEVELtune());
	m_soundefect.play();

	clearObjects();                 
	loadlevel();                       //set the same level

	timer = 0;                          //reset level timer
	m_timer.restart();					//reset level timer
	m_clock.restart();					//reset level clock
	m_player->decreaselife();			//decrease life


	
}

void Controller::resetscore()
{
	m_player->inishialScore();
}

void Controller::handelcolision()
{
	bool fall = true;
	
	for (size_t i = 0; i < m_boardPtr.size(); i++)
	{
		if (m_boardPtr[i])
			if (m_player->getGlobalBound().intersects(m_boardPtr[i]->getGlobalBound()))
			{
				fall = false;
				if (m_player) {
					m_player->collideWith(*m_boardPtr[i]);
			
					if (m_player->addTime())
					{
						m_levelTime += 10;

					}
					if (m_player->addEnemy()) {

						if (m_level == 1) {
							m_Enemy.push_back(std::make_unique<RandomMoveEnemy>(Resources::instance().getEnemy1(), sf::Vector2f(4 * TILE_SIZE, 4 * TILE_SIZE), TILE_SIZE));
							m_enemyidx++;
						}
						if (m_level == 2)
						{
							m_Enemy.push_back(std::make_unique<ConstantMoveEnemy>(Resources::instance().getEnemy2(), sf::Vector2f(4 * TILE_SIZE, 4 * TILE_SIZE), TILE_SIZE));
							m_enemyidx++;
						}
						if (m_level == 3||m_level==4)
						{
							m_Enemy.push_back(std::make_unique<TowardPlayerEnemy>(Resources::instance().getEnemy3(), sf::Vector2f(4 * TILE_SIZE, 4 * TILE_SIZE), TILE_SIZE, *m_player));
							m_enemyidx++;
						}
					
					}
					

				}

				if (m_boardPtr[i]->isDead())
				{
					
					m_boardPtr.erase(m_boardPtr.begin() + i);
					
				}
			}
		


	}
	if (fall)
	{
		fall = true;
		m_player->setposition(Fall(m_player->getposition()));
	
	}

	for (size_t i = 0; i < m_Enemy.size(); i++)
	{
		for (int j = 0; j < m_boardPtr.size(); j++)
		{
			if (m_Enemy[i]->getGlobalBound().intersects(m_boardPtr[j]->getGlobalBound()))
			{
				
				if (m_Enemy[i])
					m_Enemy[i]->collideWith(*m_boardPtr[j]);

				
				
			}
		}
		

	}

	for (size_t i = 0; i < m_Enemy.size(); i++)
	{
		if (m_Enemy[i])
			if (m_player->getGlobalBound().intersects(m_Enemy[i]->getGlobalBound()))
			{

				if (m_player)
					m_player->collideWith(*m_Enemy[i]);
			}
	}

	m_currentLife = m_player->getLife();            //save current life in case u need to reset level
	m_currentScore = m_player->getScore(); //save current score in case u need to reset level
	
	if (m_player->isDead() || timer > m_levelTime)
	{
		resertlevel();
	}

}

//load matrix read one level from file each time and keep the level in  vector<vector<char>>  for reset use
bool Controller::loadmatrix()
{
	if (m_file.eof())
		return false;

	m_file >> m_row >> m_col >> m_levelTime;
	m_col++;                                             //leave some space for toolbar

	m_matrix.resize(m_row);                              //allocate memory
	for (size_t i = 0; i < m_row; i++)


	{
		m_matrix[i].resize(m_col);
	}

	char c = m_file.get();

	while (!m_file.eof())
	{
		for (size_t i = 0; i < m_row; i++)
		{
			for (size_t j = 0; j < m_col; j++)
			{
				m_matrix[i][j] = m_file.get();
				if (m_matrix[i][j] == '*')
				{
					m_MoneyAmount++;
				}
			}
		}

		m_file.get();
		break;
	}


	return true;
}







void Controller::drawBoard()
{
	for (int i = 0; i < m_boardPtr.size(); i++)
	{
		m_boardPtr[i]->draw(m_window);
	}
}

void Controller::drawPlayer()
{
	if (m_player)
	{
		m_player->draw(m_window);
	}
}

void Controller::drawshapes()
{
	drawPlayer();
	drawBoard();
	drawEnemy();
}

void Controller::displaywindow()
{
	m_window.display();
}

void Controller::clearwindow()
{
	m_window.clear(sf::Color::White);
	m_window.draw(m_background);
}

void Controller::drawtoolboar()
{
	m_window.draw(m_scoreToolbar);
}

bool Controller::levelcomplited()
{

	if (m_player->getMoney() == 0)
	{
		m_MoneyAmount = 0;
		return true;
	}

	return false;
}

void Controller::movechareters()
{

	m_player->move(sf::Vector2f(1, 1), m_time,check(m_player->getposition()));

	for (int i = 0; i < m_Enemy.size(); i++)
	{
		m_Enemy[i]->move(sf::Vector2f(1, 1), m_time,0);
	}
}

void Controller::clearObjects()
{
	m_boardPtr.clear();
	m_Enemy.clear();
}


void Controller::run()
{
	cratewindow();
	m_window.setFramerateLimit(250);
	m_time = m_clock.restart().asSeconds();
	while (loadmatrix())
	{
		timer = m_timer.restart().asSeconds();
		loadlevel();

		while (m_window.isOpen())
		{
			timer = m_timer.getElapsedTime().asSeconds();

			draw();
			movechareters();
			handelcolision();

			if (levelcomplited())
			{
				m_soundefect.setBuffer(Resources::instance().getNEXTLEVELtune());
				m_soundefect.play();
				m_currentScore += 50 * m_level;
				m_player->increasLevel();
				m_level++;
				break;
			}


			if (m_player->getLife() <= 0)
			{
				m_music.pause();
				m_soundefect.setBuffer(Resources::instance().getGAMEOVERtune());
				m_soundefect.play();
				clearObjects();

				m_background.setTexture(&Resources::instance().getGameOver());


				while (m_window.isOpen())
				{
					m_window.clear(sf::Color::White);
					m_window.draw(m_background);
					m_window.display();


					std::this_thread::sleep_for(5s);
					m_window.close();
				}

				exit(EXIT_SUCCESS);
			}
		}

	}


	computeFinish();

}


void Controller::computeFinish()
{

	m_soundefect.stop();
	m_background.setTexture(&Resources::instance().getWIN());
	m_soundefect.setBuffer(Resources::instance().getWINtune());
	m_soundefect.play();


	while (m_window.isOpen())
	{
		m_scoreString.str("");
		m_scoreString << "Your score:    " << m_player->getScore() << endl;
		m_scoreToolbar.setPosition(width / 2, height / 2);
		m_scoreToolbar.setColor(sf::Color::Blue);
		m_scoreToolbar.setString(m_scoreString.str());

		m_window.clear(sf::Color::Blue);
		m_window.draw(m_background);
		m_window.draw(m_scoreToolbar);
		m_window.display();


		std::this_thread::sleep_for(10s);
		m_window.close();




	}

	exit(EXIT_SUCCESS);

}
int Controller::check(Vector2f D)
{


	m_shape2.setPosition(D);
	m_shape2.move({ 0,-m_movespeed * m_time });

	bool ladder = false;
	bool floor = true;

	for (int i = 0; i < m_boardPtr.size(); i++)
	{
		if (m_shape2.getGlobalBounds().intersects(m_boardPtr[i]->getGlobalBound()))
		{

		
			if (m_boardPtr[i]->c() == 'H')
			{

				ladder = true;//can go up
			}
		}
	}
	m_shape2.setPosition(D);
	m_shape2.move({ 0,m_movespeed * m_time });
	for (int i = 0; i < m_boardPtr.size(); i++)
	{
		if (m_shape2.getGlobalBounds().intersects(m_boardPtr[i]->getGlobalBound()))
		{

			if (m_boardPtr[i]->c() == '#')
			{

				floor = false;
			}
		}
	}

	if (ladder && floor)
	{
		return 0;
	}
	else if (ladder && !floor)
	{
		return 1; 
	}
	else if (!ladder && floor)
	{
		return 2; 
	}
	else
	{
		return 3;
	}
}
Vector2f Controller::Fall(Vector2f pos)
{
	m_shape2.setPosition(pos);
	m_shape2.move({ 0,-m_movespeed * m_time });
	

	bool down = true;

	while (down)
	{

		for (int i = 0; i < m_boardPtr.size(); i++)
		{
			
			if (m_shape2.getGlobalBounds().intersects(m_boardPtr[i]->getGlobalBound()))
			{
				
				
				if (m_boardPtr[i]->c() == '#')
				{
					
					down = false;
				
				}
				
			}
		}

		
		m_shape2.move({ 0,m_movespeed * m_time });
	
	}
	
	return(m_shape2.getPosition());
}