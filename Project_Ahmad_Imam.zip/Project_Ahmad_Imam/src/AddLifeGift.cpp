#include "AddLifeGift.h"
#include "Player.h"


AddLifeGift::~AddLifeGift()
{
}

void AddLifeGift::collideWith(GameObject& other)
{
	other.collideWith(*this);
}

void AddLifeGift::collideWith(Player& other)
{
	m_isDead = true;                           //to earase from vector 
	other.collideWith(*this);
}
void AddLifeGift::collideWith(Enemy& other)
{

}

void AddLifeGift::collideWith(Wall& other)
{

}

void AddLifeGift::collideWith(Money& other)
{

}

void AddLifeGift::collideWith(Rod& other)
{

}
void AddLifeGift::collideWith(Ladder& other)
{

}
void AddLifeGift::collideWith(AddLifeGift& other)
{

}
void AddLifeGift::collideWith(AddScoreGift& other)
{

}
void AddLifeGift::collideWith(AddTimeGift& other)
{

}
void AddLifeGift::collideWith(AddEnemyGift& other)
{

}
void AddLifeGift::collideWith(Gift& other)
{
	other.collideWith(*this);
}