#pragma once
#include <SFML/Graphics.hpp>
#include "NonSelfMovment.h"

class Gift :public NonSelfMovment
{
public:
	using NonSelfMovment::NonSelfMovment;

	virtual ~Gift();

	virtual void collideWith(GameObject& other)=0;
	virtual void collideWith(Player& other)=0;
	virtual void collideWith(Enemy& other)=0;
	virtual void collideWith(Wall& other)=0;
	virtual void collideWith(Money& other)=0;
	virtual void collideWith(Rod& other)=0;
	virtual void collideWith(Gift& other)=0;
	virtual void collideWith(Ladder& other)=0;
	virtual void collideWith(AddLifeGift& other)=0;
	virtual void collideWith(AddScoreGift& other)=0;
	virtual void collideWith(AddEnemyGift& other)=0;
	virtual void collideWith(AddTimeGift& other)=0;
	virtual char c();


};