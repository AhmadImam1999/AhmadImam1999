#pragma once
#include "Setting.h"
#include <SFML/Graphics.hpp>

class Money;
class Wall;
class Rod;
class Enemy;
class Player;
class Ladder;
class AddLifeGift;
class AddScoreGift;
class AddTimeGift;
class AddEnemyGift;
class Gift;



using sf::Texture;
using sf::Vector2f;
using sf::RectangleShape;
using sf::RenderWindow;
using sf::FloatRect;

class GameObject
{
public:
	
	GameObject();//constrcture
	GameObject(const Texture& texture,const Vector2f position,const float size);//constrcture

	virtual ~GameObject();//destrcture


	//-------- get function------------------
	virtual const Vector2f& getposition() const;
	virtual  void setposition(Vector2f pos) ;
	virtual Vector2f getSize()const;
	FloatRect getGlobalBound()const;
	bool isDead() const;
	//------------collision-------------------
	virtual void collideWith(GameObject& other) = 0;
	virtual void collideWith(Player& other) = 0;
	virtual void collideWith(Enemy& other) = 0;
	virtual void collideWith(Wall& other) = 0;
	virtual void collideWith(Gift& other) = 0;
	virtual void collideWith(Money& other) = 0;
	virtual void collideWith(Rod& other) = 0;
	virtual void collideWith(Ladder& other) = 0;
	virtual void collideWith(AddLifeGift& other) = 0;
	virtual void collideWith(AddScoreGift& other) = 0;
	virtual void collideWith(AddEnemyGift& other) = 0;
	virtual void collideWith(AddTimeGift& other) = 0;

	virtual void draw(RenderWindow& window);


protected:
	RectangleShape m_shape;
	Vector2f m_position;
	bool m_isDead;

};

