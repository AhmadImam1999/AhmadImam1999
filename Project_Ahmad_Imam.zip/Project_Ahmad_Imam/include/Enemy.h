#pragma once
#include "SelfMovment.h"


class Enemy : public SelfMovment
{
public:
	Enemy();
	Enemy(const sf::Texture& texture, const sf::Vector2f& pos, float size);
	virtual ~Enemy();


	virtual void collideWith(GameObject& other);
	virtual void collideWith(Player& other);
	virtual void collideWith(Enemy& other);
	virtual void collideWith(Wall& other);
	virtual void collideWith(Money& other);
	virtual void collideWith(Rod& other);
	virtual void collideWith(Gift& other);
	virtual void collideWith(Ladder& other);
	virtual void collideWith(AddLifeGift& other) ;
	virtual void collideWith(AddScoreGift& other) ;
	virtual void collideWith(AddEnemyGift& other) ;
	virtual void collideWith(AddTimeGift& other) ;

	virtual Vector2f setDirection(sf::Vector2f& direction, float time ,int D);

	void setRandomDirection(float time);
	void setConstant_Direction(float time);
private:
	sf::Clock m_clock;
	sf::Time m_time;



};

