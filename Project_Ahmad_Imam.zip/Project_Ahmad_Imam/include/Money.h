#pragma once
#include <SFML/Graphics.hpp>
#include "NonSelfMovment.h"

class Money :public NonSelfMovment
{
public:
	using NonSelfMovment::NonSelfMovment;

	virtual ~Money();

	virtual void collideWith(GameObject& other);
	virtual void collideWith(Player& other);
	virtual void collideWith(Enemy& other);
	virtual void collideWith(Wall& other);
	virtual void collideWith(Money& other);
	virtual void collideWith(Rod& other);
	virtual void collideWith(Ladder& other);
	virtual void collideWith(Gift& other);
	virtual void collideWith(AddLifeGift& other);
	virtual void collideWith(AddScoreGift& other);
	virtual void collideWith(AddEnemyGift& other);
	virtual void collideWith(AddTimeGift& other);
	virtual char c();

};