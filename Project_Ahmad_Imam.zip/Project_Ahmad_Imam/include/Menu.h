#pragma once
#include "Resources.h"
#include "Controller.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

const int NUM_OF_BUTTONS = 4;

class Menu
{
public:
	//---------- c-tor / d-tor ---------------
	Menu();
	Menu(float height,float width);

	~Menu();
	void buildmenu();
	void openAsk(sf::RenderWindow& window);

	//---------handel menu ----------------
	void run();
	void Handelmenu();
	void moveup();
	void movedown();

	//---------- get --------------------
	int getselecteditem() const { return m_selectedItemIndex; }

	//------------ set ---------------
	void setsize(float width,float height);

	//---------- draw ----------------
	void drawButoons();
	void draw();
	void creatwindow();


private:
	float m_width;         //window size
	float m_hegiht;		  //window size

	int m_selectedItemIndex;     //check wich button pressed
	sf::RectangleShape m_background;
	sf::RectangleShape m_help;
	sf::Text m_menu[NUM_OF_BUTTONS];     //vector of buttons
	sf::RenderWindow m_menuwindow;
	sf::Music m_music;
	
};