#pragma once
#include "Enemy.h"
#include "Player.h"

class TowardPlayerEnemy :public Enemy
{
public:
	//------------- ctor /  dtor -------------------------------
	TowardPlayerEnemy(const sf::Texture& texture,const sf::Vector2f& pos,float size,Player player);          //gets the player by value in order to chase player
	virtual ~TowardPlayerEnemy();

	//----------- set direction ovveride -----------------------
	virtual Vector2f setDirection(sf::Vector2f& direction,float time,int D) override;

	float nearPlayer(float x, float y);          //          

protected:
	Player m_player;
};