#pragma once
#include "Enemy.h"

class RandomMoveEnemy :public Enemy
{
public:

	RandomMoveEnemy();
	RandomMoveEnemy(const sf::Texture& texture, const sf::Vector2f& pos, float size);
	virtual ~RandomMoveEnemy();

	virtual Vector2f setDirection(sf::Vector2f& direction, float time,int D) override;


private:


};
