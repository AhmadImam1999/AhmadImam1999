#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <memory>
#include "Resources.h"
#include"SelfMovment.h"
#include "Money.h"
#include"Setting.h"



class Player :public SelfMovment
{
public:
	
	Player();//constrcture
	Player(const sf::Texture& texture,const sf::Vector2f& pos,const float size,const int& life,const int& score,const int& money);

	virtual ~Player();//distrcture


	virtual Vector2f setDirection(sf::Vector2f& direction,float time,int D);
	virtual void setposition(Vector2f pos);
	virtual const Vector2f& getposition() const;
	int getLife()const;
	int getScore()const;
	int getMoney()const;
	sf::Vector2f getDirection()const;
	bool isEnemyColide() const;
	bool addTime()const;
	bool addEnemy()const;
	bool Dig()const;
	static int increasLevel();
	void decreaselife();
	void setLife(int currentlife);
	void setMoney(int currentDiamonds);
	void Addscore(int scoreToAdd);
	void inishialScore();
	virtual void collideWith(GameObject& other);
	virtual void collideWith(Player& other);
	virtual void collideWith(Enemy& other);
	virtual void collideWith(Wall& other);
	virtual void collideWith(Money& other);
	virtual void collideWith(Rod& other);
	virtual void collideWith(Gift& other);
	virtual void collideWith(Ladder& other);
	virtual void collideWith(AddLifeGift& other);
	virtual void collideWith(AddScoreGift& other);
	virtual void collideWith(AddEnemyGift& other);
	virtual void collideWith(AddTimeGift& other);

private:

	float m_speed;
	sf::Vector2f m_inishialPositions;
	static int m_level;
	int m_life;
	int m_score;
	int m_moneyCounter;
	bool m_isdeadEnemyColision;
	bool m_isdeadMoneyOverLimit;
	bool add_Time=false;
	bool add_Enemy = false;
	bool dig=false;

	sf::Sound m_soundefect;

};


























